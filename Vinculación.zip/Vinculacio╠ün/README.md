Para modulos de scrape
1. Ir a la carpeta backend
2. Abrir terminal
3. Instalar npm install puppeteer
4. ejecutar node scrape.js
5. Comprobar el contenido en data/auto_knowlege.js